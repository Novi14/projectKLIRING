package com.example.homekliring.utils

object ErrorCode  {
    const val ERR_INTERNET_CONNECTION = 101
    const val REQUEST_TIME_OUT = 102
}